from flask import Flask, render_template, jsonify, request
import json
import os
import time

app = Flask(__name__)

# Remove injected debug code from responses
@app.after_request
def remove_debug_code(response):
    if response.mimetype == 'text/html':
        data = response.get_data(as_text=True)
        # Remove debug script and panel
        data = data.replace(
            '''    <script>
        // Capture console.log output and display on page
        const consoleLogs = [];
        const originalLog = console.log;
        const originalError = console.error;
        
        console.log = function(...args) {
            originalLog.apply(console, args);
            consoleLogs.push(args.join(' '));
            // Also update the page if debug panel exists
            const debugPanel = document.getElementById('debug-panel-logs');
            if (debugPanel) {
                debugPanel.innerHTML = consoleLogs.slice(-20).join('<br>');
                debugPanel.scrollTop = debugPanel.scrollHeight;
            }
        };
        
        console.error = function(...args) {
            originalError.apply(console, args);
            consoleLogs.push('❌ ' + args.join(' '));
        };
        
        console.log('📄 HTML body loaded - inline test');
        window.addEventListener('error', (e) => {
            console.error('❌ Global error:', e.message, e.filename, e.lineno);
        });
    </script>''',
            ''
        )
        response.set_data(data)
    return response

# Global state for vendor file selection
class AppState:
    current_vendor_file = 'vendor3-3.json'

app_state = AppState()

# Load schema data for sub-pillar definitions
def load_schema_data():
    """Load schema with sub-pillar definitions"""
    schema_file = os.path.join(os.path.dirname(__file__), 'schema3-3.json')
    try:
        with open(schema_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if 'dfir_capability_taxonomy_v3.2' in data:
                return data['dfir_capability_taxonomy_v3.2']
    except Exception as e:
        print(f"Error loading schema: {e}")
    return {}

# Extract sub-pillar definitions
def extract_sub_pillars():
    """Extract all 20 sub-pillars with definitions from schema"""
    schema = load_schema_data()
    sub_pillars = []
    
    if 'pillars' in schema:
        for pillar_key, pillar_data in schema['pillars'].items():
            pillar_code = pillar_data.get('code', '')
            pillar_name = pillar_data.get('focus', '')
            
            if 'sub_capabilities' in pillar_data:
                for sub_cap in pillar_data['sub_capabilities']:
                    sub_pillars.append({
                        'id': sub_cap.get('id', ''),
                        'pillar_code': pillar_code,
                        'pillar_name': pillar_name,
                        'name': sub_cap.get('name', ''),
                        'definition': sub_cap.get('definition', ''),
                        'activities': sub_cap.get('granular_activities', [])
                    })
    
    return sub_pillars

# Load vendor data
def load_vendor_data(vendor_file=None):
    """Load vendor data from the specified JSON file"""
    if vendor_file is None:
        vendor_file = app_state.current_vendor_file
    
    vendors = []
    filepath = os.path.join(os.path.dirname(__file__), vendor_file)
    
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Handle both array and dict formats
                if isinstance(data, list):
                    vendors.extend(data)
                elif isinstance(data, dict):
                    # If it's a dict, find any list values
                    for key, value in data.items():
                        if isinstance(value, list):
                            vendors.extend(value)
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError) as e:
            print(f"Error loading {vendor_file}: {e}")
    
    return vendors

# Field metadata for descriptions and full names
FIELD_METADATA = {
    'vendor': {
        'name': 'Vendor Name',
        'description': 'The name of the DFIR (Digital Forensics & Incident Response) vendor or service provider'
    },
    'region': {
        'name': 'Region',
        'description': 'Geographic region where the vendor primarily operates (e.g., North America, Europe, APAC, Global)'
    },
    'specialization': {
        'name': 'Specialization',
        'description': 'The primary area of focus or expertise for the vendor'
    },
    'is_startup': {
        'name': 'Is Startup',
        'description': 'Whether the company is a startup (true/false)'
    },
    'is_ai_first': {
        'name': 'AI-First',
        'description': 'Whether the vendor is primarily AI-driven in their approach (true/false)'
    },
    'ir_focus_type': {
        'name': 'IR Focus Type',
        'description': 'Core Competency = IR is primary work product; Assistance Component = IR provided as feature/support'
    },
    'PLA': {
        'name': 'Planning (PLA)',
        'description': 'Organizational Readiness and Breach Preparation - capability score 1-5'
    },
    'INV': {
        'name': 'Investigation (INV)',
        'description': 'Evidence Identification, Collection, and Analytical Reconstruction - capability score 1-5'
    },
    'REM': {
        'name': 'Remediation (REM)',
        'description': 'Threat Containment and Business Restoration - capability score 1-5'
    },
    'PMG': {
        'name': 'Program Management (PMG)',
        'description': 'Incident Lifecycle Oversight and Communication - capability score 1-5'
    },
    'LAW': {
        'name': 'Legal (LAW)',
        'description': 'Legal Admissibility and Judicial Support - capability score 1-5'
    },
    'capability_analysis': {
        'name': 'Capability Analysis',
        'description': 'Detailed explanation of the vendor\'s key capabilities and differentiators'
    }
}

# Scoring legend
SCORE_LEGEND = {
    '1': 'Manual - Human-led with no technological automation',
    '2': 'Insufficient Evidence - Service provided but AI integration not verified',
    '3': 'AI-Augmented - Basic generative AI assistants for summarization/drafting',
    '4': 'Advanced AI - Specialized models perform deep correlation with human validation',
    '5': 'Fully Agentic - Autonomous systems that independently plan and execute'
}

@app.route('/')
def index():
    static_dir = os.path.join(os.path.dirname(__file__), 'static')
    def mtime_or_now(name: str) -> int:
        try:
            return int(os.path.getmtime(os.path.join(static_dir, name)))
        except Exception:
            return int(time.time())

    static_versions = {
        'app_js': mtime_or_now('app.js'),
        'style_css': mtime_or_now('style.css'),
    }

    return render_template(
        'index.html',
        field_metadata=FIELD_METADATA,
        score_legend=SCORE_LEGEND,
        static_versions=static_versions,
    )

@app.route('/api/vendors')
def get_vendors():
    """Get all vendors with optional filtering"""
    vendors = load_vendor_data()
    
    # Get filter parameters
    search_query = request.args.get('search', '').lower()
    filters = {}
    
    # Parse filter parameters
    for key in request.args:
        if key.startswith('filter_'):
            field_name = key.replace('filter_', '')
            value = request.args.get(key)
            if value:
                filters[field_name] = value.lower()
    
    # Apply filters
    filtered_vendors = []
    for vendor in vendors:
        match = True
        
        # Apply field-specific filters
        for field, filter_value in filters.items():
            if field in vendor:
                vendor_value = str(vendor[field]).lower()
                if filter_value not in vendor_value:
                    match = False
                    break
        
        # Apply search across all fields
        if search_query and match:
            found = False
            for key, value in vendor.items():
                if search_query in str(value).lower():
                    found = True
                    break
            match = found
        
        if match:
            filtered_vendors.append(vendor)
    
    return jsonify(filtered_vendors)

@app.route('/api/field-values/<field>')
def get_field_values(field):
    """Get unique values for a specific field"""
    vendors = load_vendor_data()
    values = set()
    
    for vendor in vendors:
        if field in vendor:
            val = vendor[field]
            if isinstance(val, bool):
                val = str(val)
            elif isinstance(val, dict):
                continue
            elif isinstance(val, list):
                continue
            values.add(str(val))
    
    return jsonify(sorted(list(values)))

@app.route('/api/metadata')
def get_metadata():
    """Get field metadata and scoring legend"""
    sub_pillars = extract_sub_pillars()
    
    # Group sub-pillars by pillar
    pillars_grouped = {}
    for sub_pillar in sub_pillars:
        pillar_code = sub_pillar['pillar_code']
        if pillar_code not in pillars_grouped:
            pillars_grouped[pillar_code] = {
                'code': pillar_code,
                'name': sub_pillar['pillar_name'],
                'description': FIELD_METADATA.get(pillar_code, {}).get('description', ''),
                'sub_pillars': []
            }
        pillars_grouped[pillar_code]['sub_pillars'].append({
            'id': sub_pillar['id'],
            'name': sub_pillar['name'],
            'definition': sub_pillar.get('definition', '')
        })
    
    return jsonify({
        'field_metadata': FIELD_METADATA,
        'score_legend': SCORE_LEGEND,
        'pillars_grouped': list(pillars_grouped.values())
    })

@app.route('/api/sub-pillars')
def get_sub_pillars():
    """Get all 20 sub-pillars with definitions and filtering options"""
    sub_pillars = extract_sub_pillars()
    
    # Group by pillar for easier frontend consumption
    pillars_grouped = {}
    for sub_pillar in sub_pillars:
        pillar_code = sub_pillar['pillar_code']
        if pillar_code not in pillars_grouped:
            pillars_grouped[pillar_code] = {
                'code': pillar_code,
                'name': sub_pillar['pillar_name'],
                'sub_pillars': []
            }
        pillars_grouped[pillar_code]['sub_pillars'].append(sub_pillar)
    
    return jsonify({
        'pillars': list(pillars_grouped.values()),
        'all_sub_pillars': sub_pillars,
        'total_count': len(sub_pillars)
    })

@app.route('/api/vendors/by-sub-pillar')
def get_vendors_by_sub_pillar():
    """Filter vendors by sub-pillar score"""
    sub_pillar_id = request.args.get('sub_pillar', '').upper()
    min_score = request.args.get('min_score', '1')
    
    try:
        min_score = int(min_score)
    except ValueError:
        min_score = 1
    
    vendors = load_vendor_data()
    filtered = []
    
    for vendor in vendors:
        if 'granular_mapping' in vendor:
            granular = vendor['granular_mapping']
            # Extract pillar code from sub_pillar_id (e.g., "PLA" from "PLA-01")
            pillar_code = sub_pillar_id.split('-')[0] if '-' in sub_pillar_id else sub_pillar_id
            
            if pillar_code in granular and sub_pillar_id in granular[pillar_code]:
                score = granular[pillar_code][sub_pillar_id]
                if isinstance(score, (int, float)) and score >= min_score:
                    filtered.append({
                        'vendor': vendor,
                        'sub_pillar_score': score
                    })
    
    return jsonify(filtered)

@app.route('/api/update-definition', methods=['POST'])
def update_definition():
    """Update pillar, sub-pillar, score, or field definitions"""
    data = request.json
    edit_type = data.get('type')
    edit_id = data.get('id')
    name = data.get('name')
    description = data.get('description')
    
    try:
        if edit_type == 'pillar':
            # Update pillar in FIELD_METADATA
            FIELD_METADATA[edit_id]['name'] = name
            FIELD_METADATA[edit_id]['description'] = description
        elif edit_type == 'score':
            # Update score in SCORE_LEGEND
            SCORE_LEGEND[edit_id] = description
        elif edit_type == 'field':
            # Update field metadata
            FIELD_METADATA[edit_id]['name'] = name
            FIELD_METADATA[edit_id]['description'] = description
        elif edit_type == 'sub-pillar':
            # Update sub-pillar definition in schema
            schema_file = os.path.join(os.path.dirname(__file__), 'schema3-3.json')
            with open(schema_file, 'r', encoding='utf-8') as f:
                full_schema = json.load(f)
            
            # Navigate to the correct location in the schema
            if 'dfir_capability_taxonomy_v3.2' in full_schema:
                schema = full_schema['dfir_capability_taxonomy_v3.2']
                if 'pillars' in schema:
                    for pillar_data in schema['pillars'].values():
                        if 'sub_capabilities' in pillar_data:
                            for sub_cap in pillar_data['sub_capabilities']:
                                if sub_cap.get('id') == edit_id:
                                    sub_cap['name'] = name
                                    sub_cap['definition'] = description
            
            # Save full schema back to file
            with open(schema_file, 'w', encoding='utf-8') as f:
                json.dump(full_schema, f, indent=2, ensure_ascii=False)
        
        return jsonify({'success': True})
    except Exception as e:
        print(f"Error updating definition: {e}")
        return jsonify({'success': False, 'error': str(e)}), 400

@app.route('/api/vendor-files', methods=['GET'])
def get_vendor_files():
    """Get list of available vendor JSON files"""
    try:
        available_files = []
        app_dir = os.path.dirname(__file__)
        
        # Find all vendor JSON files dynamically
        for filename in os.listdir(app_dir):
            # Match vendor files: vendor*.json, Vendor*.json, or *researched*.json
            filename_lower = filename.lower()
            if (filename.endswith('.json') and 
                (filename_lower.startswith('vendor') or 'researched' in filename_lower or 'validated' in filename_lower)):
                filepath = os.path.join(app_dir, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                        # Count vendors
                        count = 0
                        if isinstance(data, list):
                            count = len(data)
                        elif isinstance(data, dict):
                            for key, value in data.items():
                                if isinstance(value, list):
                                    count = len(value)
                                    break
                        
                        # Create display name from filename
                        display_name = filename.replace('.json', '')
                        available_files.append({
                            'filename': filename,
                            'name': display_name,
                            'count': count
                        })
                except Exception as err:
                    print(f"Error reading {filename}: {err}")
                    pass
        
        # Sort by filename for consistent ordering
        available_files.sort(key=lambda x: x['filename'].lower())
        
        return jsonify({
            'files': available_files,
            'current': app_state.current_vendor_file
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/switch-vendor-file', methods=['POST'])
def switch_vendor_file():
    """Switch to a different vendor file"""
    try:
        data = request.get_json()
        new_file = data.get('filename')
        
        # Validate the file exists
        filepath = os.path.join(os.path.dirname(__file__), new_file)
        if not os.path.exists(filepath):
            return jsonify({'success': False, 'error': 'File not found'}), 404
        
        # Verify it's a valid JSON file
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                test_data = json.load(f)
        except:
            return jsonify({'success': False, 'error': 'Invalid JSON file'}), 400
        
        # Switch the file
        app_state.current_vendor_file = new_file
        
        return jsonify({
            'success': True,
            'current': app_state.current_vendor_file
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False, use_reloader=False, port=5000)
